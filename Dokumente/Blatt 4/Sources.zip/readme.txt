Diese Datei enthält eine kurze Erklärung über den Inhalt dieser zip-Datei.

/drwDictToTTL - Script zum Konvertieren in ttl
/lightgreen - Theme für OntoWiki
/public_html - Homepage
/searchbox - Extension für OntoWiki
/Vokabular - Vokabular zur Personendatenbank
default.ini - Config Datei für die Einbindung vom Theme
readme.txt - diese Datei
welcome.phtml - Willkommensseite im OntoWiki
